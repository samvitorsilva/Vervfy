import { expect, test, type Locator, type Page, type Route } from "@playwright/test";

const username = process.env.PLAYWRIGHT_USERNAME;
const password = process.env.PLAYWRIGHT_PASSWORD;
const externalBackend = Boolean(process.env.PLAYWRIGHT_BACKEND_URL);
const externalApp = Boolean(process.env.PLAYWRIGHT_BASE_URL);

function makeWav(): Buffer {
  const sampleRate = 22_050;
  const seconds = 6;
  const sampleCount = sampleRate * seconds;
  const dataSize = sampleCount * 2;
  const wav = Buffer.alloc(44 + dataSize);

  wav.write("RIFF", 0);
  wav.writeUInt32LE(36 + dataSize, 4);
  wav.write("WAVE", 8);
  wav.write("fmt ", 12);
  wav.writeUInt32LE(16, 16);
  wav.writeUInt16LE(1, 20);
  wav.writeUInt16LE(1, 22);
  wav.writeUInt32LE(sampleRate, 24);
  wav.writeUInt32LE(sampleRate * 2, 28);
  wav.writeUInt16LE(2, 32);
  wav.writeUInt16LE(16, 34);
  wav.write("data", 36);
  wav.writeUInt32LE(dataSize, 40);

  for (let index = 0; index < sampleCount; index += 1) {
    const sample = Math.sin((2 * Math.PI * 440 * index) / sampleRate) * 0.15;
    wav.writeInt16LE(Math.round(sample * 32_767), 44 + index * 2);
  }
  return wav;
}

async function loadMockPlaybackTrack(
  page: Page,
  title: string,
  trackNumber: number,
  artist = "Vervfy Test Artist",
): Promise<Locator> {
  const id = `playwright-track-${trackNumber}`;
  await page.route("**/api/tracks", (route) =>
    route.fulfill({
      json: {
        tracks: [
          {
            id,
            title,
            artist,
            album: "Playwright Test Album",
            duration: 30,
            has_cover: false,
            cover_source: "placeholder",
            cover_url: `/api/tracks/${id}/cover`,
            stream_url: `/api/tracks/${id}/stream`,
            custom_lyrics: null,
          },
        ],
      },
    }),
  );
  await page.reload();
  const trackCard = page.locator(".card").filter({ hasText: title });
  await expect(trackCard).toBeVisible();
  return trackCard;
}

test("playlist add-songs dialog searches and filters the library", async ({ page }) => {
  test.skip(
    externalApp || externalBackend,
    "This deterministic playlist test uses the local mock backend.",
  );
  await page.goto("/login");
  await page.getByLabel("Username").fill("playwright");
  await page.getByLabel("Password").fill("playwright-test-password");
  await page.getByRole("button", { name: "Log in" }).click();
  await expect(page).toHaveURL(/\/$/);
  await loadMockPlaybackTrack(page, "Miles & Miles", 57, "AJ Vitanza");

  await page.getByRole("button", { name: "Playlists" }).click();
  await page.getByRole("button", { name: "New playlist" }).first().click();
  await page.getByLabel("Playlist name").fill("Searchable playlist");
  await page.getByRole("button", { name: "Create", exact: true }).click();
  await page.getByRole("button", { name: "Add songs" }).click();

  const dialog = page.getByRole("dialog", { name: "Add tracks to playlist" });
  const search = dialog.getByRole("searchbox", { name: "Search songs, artists, or albums" });
  await expect(search).toBeVisible();
  await search.fill("AJ Vitanza");
  const trackRow = dialog.locator(".qp-row");
  await expect(trackRow).toHaveCount(1);
  await expect(trackRow).toContainText("Miles & Miles");
  await search.fill("nothing matches this");
  await expect(dialog.getByText("No tracks match your search.")).toBeVisible();
  await search.fill("Playwright Test Album");
  await expect(trackRow).toHaveCount(1);
  await trackRow.click();
  await expect(trackRow).toHaveCount(0);
  await expect(page.locator(".toasts .toast").last()).toContainText(
    "Added “Miles & Miles” to the playlist.",
  );
});

test("track three-dots menu stays within the viewport", async ({ page }) => {
  test.skip(
    externalApp || externalBackend,
    "This deterministic menu test uses the local mock backend.",
  );
  await page.setViewportSize({ width: 390, height: 640 });
  await page.goto("/login");
  await page.getByLabel("Username").fill("playwright");
  await page.getByLabel("Password").fill("playwright-test-password");
  await page.getByRole("button", { name: "Log in" }).click();
  await expect(page).toHaveURL(/\/$/);
  const trackCard = await loadMockPlaybackTrack(page, "menu-position", 58);
  await trackCard.getByRole("button", { name: "More options for menu-position" }).click();

  const menu = page.getByRole("menu", { name: "Options for menu-position" });
  await expect(menu).toBeVisible();
  const bounds = await menu.evaluate((element) => {
    const rect = element.getBoundingClientRect();
    return {
      left: rect.left,
      top: rect.top,
      right: rect.right,
      bottom: rect.bottom,
      width: window.innerWidth,
      height: window.innerHeight,
    };
  });
  expect(bounds.left).toBeGreaterThanOrEqual(0);
  expect(bounds.top).toBeGreaterThanOrEqual(0);
  expect(bounds.right).toBeLessThanOrEqual(bounds.width);
  expect(bounds.bottom).toBeLessThanOrEqual(bounds.height);
  await expect(menu.getByRole("menuitem", { name: "Remove from library" })).toBeVisible();
});

test("sleep timer can be scheduled and cancelled from the player", async ({ page }) => {
  test.skip(
    externalApp || externalBackend,
    "This deterministic timer test uses the local mock backend.",
  );
  await page.goto("/login");
  await page.getByLabel("Username").fill("playwright");
  await page.getByLabel("Password").fill("playwright-test-password");
  await page.getByRole("button", { name: "Log in" }).click();
  await expect(page).toHaveURL(/\/$/);
  const trackCard = await loadMockPlaybackTrack(page, "sleep-timer", 59);
  await trackCard.click();

  const timerButton = page.getByRole("button", { name: "Sleep timer" });
  await expect(timerButton).toBeEnabled();
  await timerButton.click();
  const timerDialog = page.getByRole("dialog", { name: "Sleep timer" });
  await timerDialog.getByRole("button", { name: "10 minutes" }).click();
  await expect(timerButton).toHaveAttribute("aria-pressed", "true");

  await timerButton.click();
  await expect(timerDialog.getByText(/Time remaining:/)).toBeVisible();
  await timerDialog.getByRole("button", { name: "Turn off timer" }).click();
  await expect(timerButton).toHaveAttribute("aria-pressed", "false");

  await timerButton.click();
  await timerDialog.getByRole("button", { name: "At end of track" }).click();
  await expect(timerButton).toHaveAttribute("aria-pressed", "true");
  await page.locator("audio").evaluate((element) => {
    element.dispatchEvent(new Event("ended"));
  });
  await expect(timerButton).toHaveAttribute("aria-pressed", "false");
});

test("sleep timer is available from the mobile and tablet player menu", async ({ page }) => {
  test.skip(
    externalApp || externalBackend,
    "This deterministic timer test uses the local mock backend.",
  );
  await page.goto("/login");
  await page.getByLabel("Username").fill("playwright");
  await page.getByLabel("Password").fill("playwright-test-password");
  await page.getByRole("button", { name: "Log in" }).click();
  await expect(page).toHaveURL(/\/$/);
  const trackCard = await loadMockPlaybackTrack(page, "mobile-sleep-timer", 60);
  await trackCard.click();

  for (const width of [768, 360]) {
    await page.setViewportSize({ width, height: width === 768 ? 1024 : 812 });
    await expect(page.locator("#nowbar .player-control-sleep-timer")).toBeHidden();
    await page.locator(".now-track-open").click();
    const player = page.getByRole("dialog", { name: "Now playing" });
    await player.getByRole("button", { name: "More options for mobile-sleep-timer" }).click();
    const menu = page.getByRole("menu", { name: "Options for mobile-sleep-timer" });
    await menu.getByRole("menuitem", { name: "Sleep timer" }).click();

    const timer = page.getByRole("dialog", { name: "Sleep timer" });
    await expect(timer).toBeVisible();
    await expect(timer).toHaveAttribute("aria-modal", "true");
    await timer.getByRole("button", { name: "10 minutes" }).click();
    await expect(timer).toHaveCount(0);

    await player.getByRole("button", { name: "More options for mobile-sleep-timer" }).click();
    await page.getByRole("menuitem", { name: "Sleep timer" }).click();
    await expect(timer.getByText(/Time remaining:/)).toBeVisible();
    await timer.getByRole("button", { name: "Turn off timer" }).click();
    await expect(timer).toHaveCount(0);
    await player.getByRole("button", { name: "Close player" }).click();
  }
});

test("login page loads its CSRF token from the JSON API", async ({ page }) => {
  const response = await page.goto("/login");
  const csp = response?.headers()["content-security-policy"] ?? "";
  expect(csp).toContain("script-src 'self' 'nonce-");
  expect(csp).not.toContain("Content-Security-Policy-Report-Only");
  expect(csp).not.toMatch(/script-src[^;]*'unsafe-inline'/);
  await expect(page.getByRole("heading", { name: "Welcome back" })).toBeVisible();
  await expect(page.getByLabel("Username")).toBeVisible();
  await expect(page.getByLabel("Password")).toBeVisible();
  await expect(page.getByRole("button", { name: "Log in" })).toBeEnabled({
    timeout: 30_000,
  });
});

test("Brazilian Portuguese is detected and the language choice persists", async ({ page }) => {
  await page.addInitScript(() => {
    Object.defineProperty(navigator, "language", { configurable: true, value: "pt-BR" });
    Object.defineProperty(navigator, "languages", { configurable: true, value: ["pt-BR", "en-US"] });
  });
  await page.goto("/login");

  await expect(page.getByRole("heading", { name: "Que bom ter você de volta!" })).toBeVisible();
  await expect(page.getByLabel("Nome de usuário")).toBeVisible();
  await expect(page.locator("html")).toHaveAttribute("lang", "pt-BR");

  await page.getByLabel("Idioma").selectOption("en");
  await expect(page.getByRole("heading", { name: "Welcome back" })).toBeVisible();
  await expect(page.locator("html")).toHaveAttribute("lang", "en");
  await page.reload();
  await expect(page.getByRole("heading", { name: "Welcome back" })).toBeVisible();
});

test("French and Spanish are detected and can be selected", async ({ page }) => {
  await page.addInitScript(() => {
    Object.defineProperty(navigator, "language", { configurable: true, value: "fr-FR" });
    Object.defineProperty(navigator, "languages", { configurable: true, value: ["fr-FR", "en-US"] });
  });
  await page.goto("/login");

  await expect(page.getByRole("heading", { name: "Bon retour" })).toBeVisible();
  await expect(page.getByLabel("Nom d’utilisateur")).toBeVisible();
  await expect(page.locator("html")).toHaveAttribute("lang", "fr");

  await page.getByLabel("Langue").selectOption("es");
  await expect(page.getByRole("heading", { name: "Qué bueno verte de nuevo" })).toBeVisible();
  await expect(page.getByLabel("Nombre de usuario")).toBeVisible();
  await expect(page.locator("html")).toHaveAttribute("lang", "es");
  await page.reload();
  await expect(page.getByRole("heading", { name: "Qué bueno verte de nuevo" })).toBeVisible();
});

test("Spanish is detected from the browser language", async ({ page }) => {
  await page.addInitScript(() => {
    Object.defineProperty(navigator, "language", { configurable: true, value: "es-MX" });
    Object.defineProperty(navigator, "languages", { configurable: true, value: ["es-MX", "en-US"] });
  });
  await page.goto("/login");

  await expect(page.getByRole("heading", { name: "Qué bueno verte de nuevo" })).toBeVisible();
  await expect(page.getByLabel("Nombre de usuario")).toBeVisible();
  await expect(page.locator("html")).toHaveAttribute("lang", "es");
});

test("login displays JSON authentication errors", async ({ page }) => {
  await page.goto("/login");
  await page.getByLabel("Username").fill("invalid-user");
  await page.getByLabel("Password").fill("invalid-password");
  await page.getByRole("button", { name: "Log in" }).click();
  await expect(page.locator(".auth-error[role='alert']")).toHaveText(
    "Incorrect username or password",
  );
  await expect(page.getByLabel("Password")).toHaveAttribute("aria-invalid", "true");
  await expect(page.getByLabel("Password")).toBeFocused();
});

test("registration gives live password length and byte-limit guidance", async ({ page }) => {
  await page.goto("/register");
  const password = page.getByLabel("Password");
  const hint = page.locator("#password-hint");

  await expect(hint).toHaveText("Use at least 8 characters.");
  await password.fill("short");
  await expect(hint).toHaveText("Add 3 more characters to meet the 8-character minimum.");
  await expect(password).toHaveAttribute("aria-invalid", "true");

  await password.fill("long-enough");
  await expect(hint).toHaveText("Password meets the 8-character minimum.");
  await expect(password).toHaveAttribute("aria-invalid", "false");

  await password.fill("é".repeat(36));
  await expect(hint).toHaveText("Password meets the 8-character minimum.");
  await expect(password).toHaveAttribute("aria-invalid", "false");

  await password.fill(`${"é".repeat(36)}a`);
  await expect(hint).toHaveText(
    "Password must be 72 UTF-8 bytes or fewer. Remove some characters.",
  );
  await expect(password).toHaveAttribute("aria-invalid", "true");
});

test("tablet and mobile can open the full now-playing screen", async ({ page }) => {
  await page.goto("/login");
  await page.evaluate(() => localStorage.removeItem("vervfy:list-mode"));
  await page.getByLabel("Username").fill("playwright");
  await page.getByLabel("Password").fill("playwright-test-password");
  await page.getByRole("button", { name: "Log in" }).click();
  await expect(page).toHaveURL(/\/$/);
  await expect(page.getByRole("heading", { name: "Your library is empty" })).toBeVisible();
  await page.locator('input[type="file"][accept^="audio/"]').first().setInputFiles({
    name: "responsive-player.wav",
    mimeType: "audio/wav",
    buffer: makeWav(),
  });

  const track = page.locator(".card").filter({ hasText: "responsive-player" });
  await expect(track).toBeVisible();
  const fallbackCover = track.locator(".card-art .generated-aura");
  await expect(fallbackCover).toBeVisible();
  await expect(fallbackCover.locator("text")).toHaveCount(0);
  await expect(fallbackCover.locator(".generated-aura-first")).toHaveCSS(
    "animation-name",
    "generatedAuraDrift",
  );
  await page.getByRole("button", { name: "List view" }).click();
  await expect(page.locator(".list .row")).toHaveCount(1);
  await page.reload();
  await expect(page.locator(".list .row")).toHaveCount(1);
  await expect(page.getByRole("button", { name: "List view" })).toHaveAttribute("aria-pressed", "true");
  await page.getByRole("button", { name: "Grid view" }).click();
  await expect(track).toBeVisible();
  await track.click();
  const nowPlayingButton = page.locator(".now-track-open");
  await expect(nowPlayingButton).toBeVisible();
  const expectNowbarOnTop = async () => {
    const nowbar = page.locator("#nowbar");
    const isOnTop = await nowbar.evaluate((bar) => {
      const rect = bar.getBoundingClientRect();
      const topmostElement = document.elementFromPoint(
        rect.left + rect.width / 2,
        rect.top + rect.height / 2,
      );
      return topmostElement !== null && bar.contains(topmostElement);
    });
    expect(isOnTop).toBe(true);
  };

  for (const viewport of [
    { width: 360, height: 812 },
    { width: 768, height: 1024 },
  ]) {
    await page.setViewportSize(viewport);
    await nowPlayingButton.click();
    const player = page.getByRole("dialog", { name: "Now playing" });
    await expect(player).toBeVisible();
    await expect(player.getByRole("button", { name: "Close player" })).toBeFocused();
    await expect(player.locator(".mobile-player-art img, .mobile-player-art .generated-aura")).toBeVisible();
    await expect(player.locator(".mobile-player-context strong")).toHaveText("Library");
    const playerMenuButton = player.getByRole("button", { name: "More options for responsive-player" });
    await playerMenuButton.click();
    const playerMenu = page.getByRole("menu", { name: "Options for responsive-player" });
    await expect(playerMenu).toBeVisible();
    await expect(playerMenu.getByRole("menuitem", { name: "Edit track details" })).toBeVisible();
    await playerMenuButton.click();
    await expect(playerMenu).toHaveCount(0);
    await expect(playerMenuButton).toBeFocused();
    for (const label of ["Previous track", "Next track", "Shuffle", "Repeat: off", "Lyrics", "Queue"]) {
      await expect(player.getByRole("button", { name: label, exact: true })).toBeVisible();
    }
    await expect(player.getByRole("button", { name: /^(Play|Pause)$/ })).toBeVisible();
    await player.getByRole("button", { name: "Close player" }).click();
    await expect(player).toHaveCount(0);
    await expect(nowPlayingButton).toBeFocused();
    const playerRegions = await page.locator("#nowbar").evaluate((element) =>
      [".now-track", ".transport", ".now-extra"].map((selector) => {
        const rect = element.querySelector(selector)!.getBoundingClientRect();
        return { left: rect.left, right: rect.right };
      }),
    );
    expect(playerRegions[0].right).toBeLessThanOrEqual(playerRegions[1].left + 1);
    expect(playerRegions[1].right).toBeLessThanOrEqual(playerRegions[2].left + 1);
    if (viewport.width === 360) {
      expect(
        await page.evaluate(
          () => document.documentElement.scrollWidth > document.documentElement.clientWidth,
        ),
      ).toBe(false);
    }
  }

  await nowPlayingButton.click();
  await page
    .getByRole("dialog", { name: "Now playing" })
    .getByRole("button", { name: "More options for responsive-player" })
    .click();
  await page.getByRole("menuitem", { name: "Edit track details" }).click();
  const trackDetails = page.getByRole("dialog", { name: "Track details" });
  await expect(trackDetails).toBeVisible();
  await expect(page.getByRole("dialog", { name: "Now playing" })).toHaveCount(0);
  await trackDetails.getByRole("button", { name: "Close" }).click();

  await page.getByRole("button", { name: "Artists" }).click();
  await expectNowbarOnTop();
  await nowPlayingButton.click();
  await expect(page.locator(".mobile-player-context strong")).toHaveText("Library");
  await page.getByRole("button", { name: "Close player" }).click();
  await page.getByRole("button", { name: "Library" }).click();

  await nowPlayingButton.click();
  const playerArtist = page.locator(".mobile-player-title-row .artist-link").first();
  const artistName = (await playerArtist.textContent())?.trim();
  expect(artistName).toBeTruthy();
  await playerArtist.click();
  await expect(page.locator(".artist-name")).toHaveText(artistName!);
  await expectNowbarOnTop();
  await page.getByRole("button", { name: "List view" }).click();
  const artistTrackRow = page.locator(".artist-page .list .row");
  await expect(artistTrackRow).toHaveCount(1);
  await artistTrackRow.getByRole("button", { name: "Add to queue" }).click();
  await expect(page.locator(".toasts .toast").last()).toContainText("Added “responsive-player” to the queue.");
  await artistTrackRow.getByRole("button", { name: "Favorite" }).click();
  await expect(artistTrackRow.getByRole("button", { name: "Remove favorite" })).toBeVisible();
  await artistTrackRow.getByRole("button", { name: "More options for responsive-player" }).click();
  const artistTrackMenu = page.getByRole("menu", { name: "Options for responsive-player" });
  await expect(artistTrackMenu.getByRole("menuitem", { name: "Play next" })).toBeVisible();
  await expect(artistTrackMenu.getByRole("menuitemcheckbox", { name: "Remove from liked songs" })).toBeVisible();
  await artistTrackMenu.getByRole("menuitem", { name: "Add to queue" }).click();
  await page.getByRole("button", { name: "Grid view" }).click();
  const artistAvatar = page.getByRole("img", { name: "Vervfy Test Artist" });
  await expect(page.locator(".artist-bio")).toHaveText(
    "Vervfy Test Artist is a verified test profile.",
  );
  await expect(page.locator(".artist-info")).toContainText("Genre: Pop");
  await expect(page.locator(".artist-info")).not.toContainText(/followers|fans/i);
  await expect(page.locator(".artist-info img")).toHaveCount(0);
  await expect(artistAvatar).toBeVisible();
  await expect(page.getByRole("link", { name: "Source: Wikipedia" })).toHaveAttribute(
    "href",
    "https://en.wikipedia.org/wiki/Vervfy_Test_Artist",
  );
  await expect(page.getByRole("link", { name: "CC BY-SA 4.0" })).toHaveAttribute(
    "href",
    "https://creativecommons.org/licenses/by-sa/4.0/",
  );
  await expect(page.locator(".artist-source")).toContainText("Shortened or adapted");

  await page.getByRole("button", { name: "Artists" }).click();
  const artistCardAvatar = page.locator(".artist-card-photo").first();
  await expect(artistCardAvatar).toBeVisible();
  await nowPlayingButton.click();
  await page.locator(".mobile-secondary").filter({ hasText: "Lyrics" }).click();
  const lyricsArtist = page.locator(".lyrics-meta .artist-link").first();
  await expect(lyricsArtist).toBeVisible();
  await lyricsArtist.click();
  await expect(page.locator(".artist-name")).toHaveText(artistName!);
});

test("public credits page keeps the nonce CSP and lists attribution", async ({ page }) => {
  const response = await page.goto("/credits");
  const csp = response?.headers()["content-security-policy"] ?? "";
  expect(csp).toContain("script-src 'self' 'nonce-");
  expect(csp).toContain("img-src 'self' data: blob:");
  expect(csp).toContain("media-src 'self' blob: https://*.supabase.co");
  expect(csp).toContain("https://*.theaudiodb.com");
  await expect(page.getByRole("heading", { name: "Credits and data sources" })).toBeVisible();
  await expect(page.getByRole("link", { name: "Wikipedia" })).toBeVisible();
  await expect(page.getByRole("link", { name: "CC BY-SA 4.0" })).toHaveAttribute(
    "href",
    "https://creativecommons.org/licenses/by-sa/4.0/",
  );
  await expect(page.getByRole("link", { name: "LRCLIB" })).toHaveAttribute(
    "href",
    "https://lrclib.net/",
  );
  await expect(page.getByText(/Artist image URLs and IDs are supplied by TheAudioDB/)).toBeVisible();
  await expect(page.getByRole("link", { name: "TheAudioDB" }).first()).toHaveAttribute(
    "href",
    "https://www.theaudiodb.com/",
  );
});

test("development CSP supports React debugging and disables service worker caching", async ({ page }) => {
  test.skip(
    externalApp || externalBackend,
    "This regression test requires the local development server.",
  );
  const response = await page.goto("/login");
  expect(response?.headers()["content-security-policy"]).toContain("'unsafe-eval'");
  await expect.poll(() =>
    page.evaluate(async () => {
      const registration = await navigator.serviceWorker.getRegistration();
      return !registration && !navigator.serviceWorker.controller;
    }),
  ).toBe(true);
});

test("disabled LRCLIB lookup makes no external lyrics request", async ({ page }) => {
  let lrclibRequests = 0;
  await page.route("**/api/config", (route) =>
    route.fulfill({ json: { lyrics_provider_lrclib: false } }),
  );
  await page.route("https://lrclib.net/**", (route) => {
    lrclibRequests += 1;
    return route.abort();
  });
  await page.goto("/login");
  await page.getByLabel("Username").fill("playwright");
  await page.getByLabel("Password").fill("playwright-test-password");
  await page.getByRole("button", { name: "Log in" }).click();
  await expect(page).toHaveURL(/\/$/);
  await expect(page.getByRole("heading", { name: "Your library is empty" })).toBeVisible();
  await page.locator('input[type="file"][accept^="audio/"]').first().setInputFiles({
    name: "lyrics-disabled.wav",
    mimeType: "audio/wav",
    buffer: makeWav(),
  });
  await expect(page.locator(".card").filter({ hasText: "lyrics-disabled" })).toBeVisible();
  await page.locator(".card").filter({ hasText: "lyrics-disabled" }).click();
  await page.setViewportSize({ width: 360, height: 812 });
  await page.locator(".now-track-open").click();
  const player = page.getByRole("dialog", { name: "Now playing" });
  const lyricsPreview = player.locator(".mobile-lyrics-preview");
  await expect(lyricsPreview).toContainText("Paste your own lyrics.");
  await lyricsPreview.click();
  const lyricsDialog = page.getByRole("dialog", { name: "Lyrics" });
  await expect(lyricsDialog.getByRole("heading", { name: "Lyrics lookup is disabled." })).toBeVisible();
  expect(lrclibRequests).toBe(0);
});

test("lyrics appear before a slow embedded-audio lookup finishes", async ({ page }) => {
  test.skip(
    externalApp || externalBackend,
    "This deterministic lyrics test uses the local mock backend.",
  );
  await page.goto("/login");
  await page.getByLabel("Username").fill("playwright");
  await page.getByLabel("Password").fill("playwright-test-password");
  await page.getByRole("button", { name: "Log in" }).click();
  await expect(page).toHaveURL(/\/$/);
  const trackCard = await loadMockPlaybackTrack(page, "Fast lyrics", 59, "AJ Vitanza");

  let releaseEmbeddedRequest: () => void = () => {};
  const embeddedRequestDelay = new Promise<void>((resolve) => {
    releaseEmbeddedRequest = resolve;
  });
  let embeddedRequestFinished = false;
  let resolveEmbeddedRequestStarted: () => void = () => {};
  const embeddedRequestStarted = new Promise<void>((resolve) => {
    resolveEmbeddedRequestStarted = resolve;
  });
  await page.route("**/api/tracks/playwright-track-59/stream", async (route) => {
    if (route.request().headers().range !== "bytes=0-262143") {
      await route.continue();
      return;
    }
    resolveEmbeddedRequestStarted();
    await embeddedRequestDelay;
    embeddedRequestFinished = true;
    try {
      await route.fulfill({
        status: 206,
        headers: { "Content-Range": "bytes 0-9/10", "Accept-Ranges": "bytes" },
        body: Buffer.alloc(10),
      });
    } catch (error) {
      if (!route.request().failure()) throw error;
    }
  });
  await page.route("https://lrclib.net/api/**", (route) => {
    if (new URL(route.request().url()).pathname.endsWith("/api/get")) {
      return route.fulfill({
        json: {
          trackName: "Fast lyrics",
          artistName: "AJ Vitanza",
          duration: 30,
          syncedLyrics: "[00:00.00]Immediate lyric line",
        },
      });
    }
    return route.fulfill({ json: [] });
  });

  await trackCard.click();
  await page.locator(".player-control-lyrics").click();
  const lyrics = page.getByRole("dialog", { name: "Lyrics" });
  await embeddedRequestStarted;
  await expect(lyrics.locator(".lyrics-line")).toHaveText("Immediate lyric line", {
    timeout: 2_000,
  });
  expect(embeddedRequestFinished).toBe(false);
  releaseEmbeddedRequest();
});

test("French lyrics screen can retry a temporary LRCLIB failure", async ({ page }) => {
  test.skip(
    externalApp || externalBackend,
    "This deterministic lyrics test uses the local mock backend.",
  );
  await page.goto("/login");
  await page.getByLabel("Username").fill("playwright");
  await page.getByLabel("Password").fill("playwright-test-password");
  await page.getByRole("button", { name: "Log in" }).click();
  await expect(page).toHaveURL(/\/$/);
  await page.evaluate(() => localStorage.setItem("vervfy:language", "fr"));
  const trackCard = await loadMockPlaybackTrack(page, "Miles & Miles", 56, "AJ Vitanza");

  const unavailableRoute = (route: Route) =>
    route.fulfill({ status: 503, body: "temporarily unavailable" });
  await page.route("https://lrclib.net/api/**", unavailableRoute);
  await trackCard.click();
  await page.locator(".player-control-lyrics").click();

  const lyrics = page.getByRole("dialog", { name: "Paroles" });
  await expect(
    lyrics.getByRole("heading", { name: "Impossible de charger les paroles. Touchez pour réessayer." }),
  ).toBeVisible();
  await page.unroute("https://lrclib.net/api/**", unavailableRoute);
  await page.route("https://lrclib.net/api/**", (route) => {
    if (new URL(route.request().url()).pathname.endsWith("/api/get")) {
      return route.fulfill({
        json: {
          trackName: "Miles & Miles",
          artistName: "AJ Vitanza",
          duration: 30,
          syncedLyrics: "[00:00.00]Recovered lyric line",
        },
      });
    }
    return route.fulfill({ json: [] });
  });
  await lyrics.getByRole("button", { name: "Réessayer" }).click();
  await expect(lyrics.locator(".lyrics-line")).toHaveText("Recovered lyric line");
});

test("cached plain lyrics upgrade to an automatically synced copy", async ({ page }) => {
  test.skip(
    externalApp || externalBackend,
    "This deterministic lyrics test uses the local mock backend.",
  );
  await page.goto("/login");
  await page.getByLabel("Username").fill("playwright");
  await page.getByLabel("Password").fill("playwright-test-password");
  await page.getByRole("button", { name: "Log in" }).click();
  await expect(page).toHaveURL(/\/$/);
  const title = "Miles & Miles";
  const artist = "AJ Vitanza";
  const trackCard = await loadMockPlaybackTrack(page, title, 58, artist);
  await page.evaluate(() => {
    localStorage.setItem(
      "vervfy:lrclib:v4:playwright-track-58",
      JSON.stringify({
        savedAt: Date.now(),
        lyrics: { source: "online-plain", text: "Plain lyric line" },
      }),
    );
  });
  await page.route("https://lrclib.net/api/**", (route) => {
    const url = new URL(route.request().url());
    if (url.pathname.endsWith("/api/get")) {
      return route.fulfill({
        json: {
          trackName: title,
          artistName: artist,
          duration: 30,
          plainLyrics: "Plain lyric line",
        },
      });
    }
    return route.fulfill({
      json: [{
        trackName: title,
        artistName: artist,
        duration: 30,
        syncedLyrics: "[00:00.00]Automatically synced line",
      }],
    });
  });

  await trackCard.click();
  await page.locator(".player-control-lyrics").click();
  const lyrics = page.getByRole("dialog", { name: "Lyrics" });
  await expect(lyrics.locator(".lyrics-line")).toHaveText("Automatically synced line");
});

test("lyrics lookup rejects timestamps from a different-duration recording", async ({ page }) => {
  test.skip(
    externalApp || externalBackend,
    "This deterministic lyrics test uses the local mock backend.",
  );
  await page.goto("/login");
  await page.getByLabel("Username").fill("playwright");
  await page.getByLabel("Password").fill("playwright-test-password");
  await page.getByRole("button", { name: "Log in" }).click();
  await expect(page).toHaveURL(/\/$/);
  const title = "Duration mismatch";
  const artist = "AJ Vitanza";
  const trackCard = await loadMockPlaybackTrack(page, title, 61, artist);
  const mismatchedRecording = {
    trackName: title,
    artistName: artist,
    duration: 34,
    syncedLyrics: "[00:00.00]Incorrectly timed lyric line",
  };
  await page.route("https://lrclib.net/api/**", (route) =>
    route.fulfill({
      json: new URL(route.request().url()).pathname.endsWith("/api/get")
        ? mismatchedRecording
        : [mismatchedRecording],
    }),
  );

  await trackCard.click();
  await page.locator(".player-control-lyrics").click();
  const lyrics = page.getByRole("dialog", { name: "Lyrics" });
  await expect(lyrics.getByRole("heading", { name: "No lyrics available" })).toBeVisible();
  await expect(lyrics.locator(".lyrics-line")).toHaveCount(0);
});

test("lyrics lookup rejects a synced match from a different album", async ({ page }) => {
  test.skip(
    externalApp || externalBackend,
    "This deterministic lyrics test uses the local mock backend.",
  );
  await page.goto("/login");
  await page.getByLabel("Username").fill("playwright");
  await page.getByLabel("Password").fill("playwright-test-password");
  await page.getByRole("button", { name: "Log in" }).click();
  await expect(page).toHaveURL(/\/$/);
  const title = "Album mismatch";
  const artist = "AJ Vitanza";
  const trackCard = await loadMockPlaybackTrack(page, title, 62, artist);
  const otherAlbum = {
    trackName: title,
    artistName: artist,
    albumName: "Different Album",
    duration: 30,
    syncedLyrics: "[00:00.00]Incorrect recording lyric line",
  };
  await page.route("https://lrclib.net/api/**", (route) =>
    route.fulfill({
      json: new URL(route.request().url()).pathname.endsWith("/api/get")
        ? otherAlbum
        : [otherAlbum],
    }),
  );

  await trackCard.click();
  await page.locator(".player-control-lyrics").click();
  const lyrics = page.getByRole("dialog", { name: "Lyrics" });
  await expect(lyrics.getByRole("heading", { name: "No lyrics available" })).toBeVisible();
  await expect(lyrics.locator(".lyrics-line")).toHaveCount(0);
});

test("lyrics lookup rejects timestamps past the end of the track", async ({ page }) => {
  test.skip(
    externalApp || externalBackend,
    "This deterministic lyrics test uses the local mock backend.",
  );
  await page.goto("/login");
  await page.getByLabel("Username").fill("playwright");
  await page.getByLabel("Password").fill("playwright-test-password");
  await page.getByRole("button", { name: "Log in" }).click();
  await expect(page).toHaveURL(/\/$/);
  const title = "Out of range timestamp";
  const artist = "AJ Vitanza";
  const trackCard = await loadMockPlaybackTrack(page, title, 63, artist);
  const invalidTiming = {
    trackName: title,
    artistName: artist,
    albumName: "Playwright Test Album",
    duration: 30,
    syncedLyrics: "[00:34.00]Out of range lyric line",
  };
  await page.route("https://lrclib.net/api/**", (route) =>
    route.fulfill({
      json: new URL(route.request().url()).pathname.endsWith("/api/get")
        ? invalidTiming
        : [invalidTiming],
    }),
  );

  await trackCard.click();
  await page.locator(".player-control-lyrics").click();
  const lyrics = page.getByRole("dialog", { name: "Lyrics" });
  await expect(lyrics.getByRole("heading", { name: "No lyrics available" })).toBeVisible();
  await expect(lyrics.locator(".lyrics-line")).toHaveCount(0);
});

test("known early LRCLIB lyrics are delayed by 2.5 seconds", async ({ page }) => {
  test.skip(
    externalApp || externalBackend,
    "This deterministic lyrics test uses the local mock backend.",
  );
  await page.goto("/login");
  await page.getByLabel("Username").fill("playwright");
  await page.getByLabel("Password").fill("playwright-test-password");
  await page.getByRole("button", { name: "Log in" }).click();
  await expect(page).toHaveURL(/\/$/);

  for (const [title, artist, trackNumber] of [
    ["Don't Let Me Down", "The Chainsmokers", 64],
    ["Just Keep Watching", "Tate McRae", 65],
  ] as const) {
    const trackCard = await loadMockPlaybackTrack(page, title, trackNumber, artist);
    await page.route("https://lrclib.net/api/**", (route) =>
      route.fulfill({
        json: {
          trackName: title,
          artistName: artist,
          albumName: "Playwright Test Album",
          duration: 30,
          syncedLyrics: "[00:01.00]Test lyric line",
        },
      }),
    );

    await trackCard.click();
    await page.locator(".player-control-lyrics").click();
    const lyrics = page.getByRole("dialog", { name: "Lyrics" });
    const lyricLine = lyrics.locator(".lyrics-line").first();
    await expect(lyricLine).toHaveText("Test lyric line");
    await lyricLine.click();
    await expect
      .poll(() =>
        page.locator("audio").evaluate((element) => (element as HTMLAudioElement).currentTime),
      )
      .toBeCloseTo(3.5, 1);
    await page.getByRole("button", { name: "Close lyrics" }).click();
    await page.unroute("https://lrclib.net/api/**");
  }
});

test("track cover can be changed and reverted in the library", async ({ page }) => {
  await page.goto("/login");
  await page.getByLabel("Username").fill("playwright");
  await page.getByLabel("Password").fill("playwright-test-password");
  await page.getByRole("button", { name: "Log in" }).click();
  await expect(page).toHaveURL(/\/$/);
  await expect(page.getByRole("heading", { name: "Your library is empty" })).toBeVisible();
  await page.locator('input[type="file"][accept^="audio/"]').first().setInputFiles({
    name: "cover-flow.wav",
    mimeType: "audio/wav",
    buffer: makeWav(),
  });
  const track = page.locator(".card").filter({ hasText: "cover-flow" });
  await expect(track).toBeVisible();
  await track.getByRole("button", { name: "More options for cover-flow" }).click();
  await page.getByRole("menuitem", { name: "Add cover" }).click();
  const coverInput = page.locator('input[type="file"][accept="image/jpeg,image/png,image/webp"]');
  await coverInput.setInputFiles({
    name: "cover.png",
    mimeType: "image/png",
    buffer: Buffer.from(
      "iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAIAAABLbSncAAAAFElEQVR4nGMUCahgwAaYsIoOWgkAsMwA7Nwb4ScAAAAASUVORK5CYII=",
      "base64",
    ),
  });
  await expect(page.locator(".track-cover-preview")).toHaveAttribute("src", /^blob:/);
  await page.getByRole("button", { name: "Save cover" }).click();
  await expect(page.getByRole("dialog", { name: /Cover for/ })).toHaveCount(0);

  await track.getByRole("button", { name: "More options for cover-flow" }).click();
  await page.getByRole("menuitem", { name: "Change cover" }).click();
  await page.getByRole("button", { name: "Remove cover" }).click();
  await expect(page.getByRole("dialog", { name: /Cover for/ })).toHaveCount(0);
});

test("artist image editor previews and saves an uploaded photo", async ({
  page,
}) => {
  test.skip(
    externalApp || externalBackend,
    "This photo editor smoke test uses the local mock backend.",
  );
  await page.goto("/login");
  await page.getByLabel("Username").fill("playwright");
  await page.getByLabel("Password").fill("playwright-test-password");
  await page.getByRole("button", { name: "Log in" }).click();
  await expect(page).toHaveURL(/\/$/);
  await expect(page.getByRole("heading", { name: "Your library is empty" })).toBeVisible();
  await page.locator('input[type="file"][accept^="audio/"]').first().setInputFiles({
    name: "photo-smoke.wav",
    mimeType: "audio/wav",
    buffer: makeWav(),
  });
  await expect(page.locator(".card").filter({ hasText: "photo-smoke" })).toBeVisible();
  await page.locator('.rail-btn[data-view="artists"]').click();
  await page.getByRole("button", { name: "Open artist page: Vervfy Test Artist" }).click();
  await expect(page.getByRole("heading", { name: "Vervfy Test Artist" })).toBeVisible();
  await page.getByRole("button", { name: "Change image" }).click();
  const editor = page.getByRole("dialog", { name: /Photo for Vervfy Test Artist/ });
  await expect(editor).toBeVisible();
  await editor.locator('input[type="file"]').setInputFiles({
    name: "artist.png",
    mimeType: "image/png",
    buffer: Buffer.from(
      "iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAIAAABLbSncAAAAFElEQVR4nGMUCahgwAaYsIoOWgkAsMwA7Nwb4ScAAAAASUVORK5CYII=",
      "base64",
    ),
  });
  await expect(editor.locator(".artist-photo-preview")).toHaveAttribute("src", /^blob:/);
  await editor.getByRole("button", { name: "Save photo" }).click();
  await expect(editor).toHaveCount(0);
  await expect(page.getByRole("button", { name: "Remove photo" })).toBeVisible();
});

test("expanded mobile player shows playback-synced lyric lines", async ({ page }) => {
  const track = {
    id: "responsive-preview-track",
    title: "synced-preview",
    artist: "Strings & Hearts",
    album: "Playwright Test Album",
    duration: 6,
    has_cover: false,
    cover_source: "audiodb",
    cover_url: "https://r2.theaudiodb.com/cover.jpg",
    stream_url: "/api/tracks/responsive-preview-track/stream",
    custom_lyrics: null,
  };
  await page.route("**/api/tracks", (route) =>
    route.fulfill({ json: { tracks: [track] } }),
  );
  await page.route("**/api/tracks/responsive-preview-track/stream", (route) =>
    route.fulfill({ contentType: "audio/wav", body: makeWav() }),
  );
  let coverRequests = 0;
  await page.route("https://r2.theaudiodb.com/**", async (route) => {
    coverRequests += 1;
    if (coverRequests === 1) {
      await route.abort();
      return;
    }
    await route.fulfill({
      contentType: "image/png",
      body: Buffer.from(
        "iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAIAAABLbSncAAAAFElEQVR4nGMUCahgwAaYsIoOWgkAsMwA7Nwb4ScAAAAASUVORK5CYII=",
        "base64",
      ),
    });
  });
  let lrclibClientHeader = "";
  await page.route("https://lrclib.net/api/get**", (route) => {
    lrclibClientHeader = route.request().headers()["lrclib-client"] ?? "";
    return route.fulfill({
      contentType: "application/json",
      body: JSON.stringify({
        trackName: track.title,
        artistName: track.artist,
        duration: track.duration + 8,
        syncedLyrics: "[00:00.00]First lyric line\n[00:02.00]Second lyric line",
        plainLyrics: "First lyric line\nSecond lyric line",
      }),
    });
  });
  await page.route("https://lrclib.net/api/search**", (route) =>
    route.fulfill({
      contentType: "application/json",
      body: JSON.stringify([
        {
          trackName: track.title,
          artistName: track.artist,
          duration: track.duration + 8,
          syncedLyrics: "[00:00.00]First lyric line\n[00:02.00]Second lyric line",
        },
      ]),
    }),
  );

  await page.goto("/login");
  await page.getByLabel("Username").fill("playwright");
  await page.getByLabel("Password").fill("playwright-test-password");
  await page.getByRole("button", { name: "Log in" }).click();
  await expect(page).toHaveURL(/\/$/);
  const trackCard = page.locator(".card").filter({ hasText: track.title });
  await expect(trackCard).toBeVisible();
  await expect.poll(() => trackCard.locator("img").evaluate((image: HTMLImageElement) => image.naturalWidth))
    .toBeGreaterThan(0);
  expect(coverRequests).toBeGreaterThanOrEqual(2);
  await trackCard.click();
  await page.setViewportSize({ width: 360, height: 812 });
  await page.locator(".now-track-open").click();

  const player = page.getByRole("dialog", { name: "Now playing" });
  await expect(player).toBeVisible();
  await expect.poll(() => page.locator("audio").evaluate((audio: HTMLAudioElement) => audio.readyState))
    .toBeGreaterThan(0);
  await expect.poll(() => page.locator("audio").evaluate((audio: HTMLAudioElement) => audio.duration))
    .toBeGreaterThan(0);
  await page.locator("audio").evaluate((audio: HTMLAudioElement) => {
    audio.currentTime = 0;
  });
  const lyricsPreview = player.locator(".mobile-lyrics-preview");
  await expect(lyricsPreview.locator(".lyric-active")).toHaveText("First lyric line");
  await expect.poll(() => lrclibClientHeader).toBe(
    "Vervfy/1.0 (https://github.com/samvitorsilva/Vervfy)",
  );
  await page.locator("audio").evaluate(async (audio: HTMLAudioElement) => {
    if (audio.paused) await audio.play();
  });
  await expect.poll(() => page.locator("audio").evaluate((audio: HTMLAudioElement) => audio.currentTime))
    .toBeGreaterThan(2);
  await expect(lyricsPreview.locator(".lyric-active")).toHaveText("Second lyric line");
  await expect(lyricsPreview.getByText("Synced to playback")).toBeVisible();

  await lyricsPreview.click();
  const lyricsDialog = page.getByRole("dialog", { name: "Lyrics" });
  await expect(lyricsDialog).toBeVisible();
  await expect(lyricsDialog.locator(".lyrics-meta .artist-link")).toHaveCount(1);
  await expect(lyricsDialog.locator(".lyrics-meta .artist-link")).toHaveText("Strings & Hearts");
  await expect(lyricsDialog).toContainText("Second lyric line");
  const phoneTrackCard = lyricsDialog.locator(".lyrics-side");
  const phoneCoverArt = lyricsDialog.locator(".lyrics-art");
  await expect.poll(() => phoneTrackCard.evaluate((element) => getComputedStyle(element).padding)).toBe("12px");
  const phoneCoverBounds = await phoneCoverArt.boundingBox();
  expect(phoneCoverBounds?.width).toBeCloseTo(96, 0);
  expect(phoneCoverBounds?.height).toBeCloseTo(96, 0);
  await page.setViewportSize({ width: 768, height: 1024 });
  const trackCardBounds = await lyricsDialog.locator(".lyrics-side").boundingBox();
  const lyricsPlayerBounds = await lyricsDialog.locator(".lyrics-player").boundingBox();
  expect(trackCardBounds?.width).toBeLessThan(260);
  expect(lyricsPlayerBounds?.height).toBeLessThan(100);
  await page.keyboard.press("Escape");
  await expect(lyricsDialog).toHaveCount(0);
  const nowbar = page.locator("#nowbar");
  const nowbarBounds = await nowbar.boundingBox();
  const transportBounds = await nowbar.locator(".transport").boundingBox();
  expect(nowbarBounds).not.toBeNull();
  expect(transportBounds).not.toBeNull();
  expect(
    Math.abs(
      nowbarBounds!.x + nowbarBounds!.width / 2 -
        (transportBounds!.x + transportBounds!.width / 2),
    ),
  ).toBeLessThan(1);
});

test("mobile player menu opens MusicBrainz cover art information", async ({ page }) => {
  const track = {
    id: "mobile-cover-info-track",
    title: "mobile-cover-info",
    artist: "Vervfy Test Artist",
    album: "Playwright Test Album",
    duration: 6,
    has_cover: false,
    cover_source: "musicbrainz",
    cover_url: "",
    stream_url: "/api/tracks/mobile-cover-info-track/stream",
    custom_lyrics: null,
  };
  await page.route("**/api/tracks", (route) =>
    route.fulfill({ json: { tracks: [track] } }),
  );
  await page.route("**/api/tracks/mobile-cover-info-track/stream", (route) =>
    route.fulfill({ contentType: "audio/wav", body: makeWav() }),
  );

  await page.goto("/login");
  await page.getByLabel("Username").fill("playwright");
  await page.getByLabel("Password").fill("playwright-test-password");
  await page.getByRole("button", { name: "Log in" }).click();
  await expect(page).toHaveURL(/\/$/);

  const trackCard = page.locator(".card").filter({ hasText: track.title });
  await expect(trackCard).toBeVisible();
  await trackCard.click();
  await page.setViewportSize({ width: 360, height: 812 });
  await page.locator(".now-track-open").click();

  const player = page.getByRole("dialog", { name: "Now playing" });
  await expect(player).toBeVisible();
  await player.getByRole("button", { name: `More options for ${track.title}` }).click();
  const menu = page.getByRole("menu", { name: `Options for ${track.title}` });
  await menu.getByRole("menuitem", { name: "Cover art info" }).click();

  const coverInfo = page.getByRole("dialog", { name: "Cover art information" });
  await expect(coverInfo).toBeVisible();
  await expect(coverInfo.getByRole("link", { name: "Cover Art Archive" })).toHaveAttribute(
    "href",
    "https://coverartarchive.org/",
  );
  await coverInfo.getByRole("button", { name: "Close cover art information" }).click();
  await expect(
    player.getByRole("button", { name: `More options for ${track.title}` }),
  ).toBeFocused();
});

test("opening the library with an expired session returns to login", async ({ page }) => {
  await page.goto("/");
  await expect(page).toHaveURL(/\/login$/);
  await expect(page.getByRole("heading", { name: "Welcome back" })).toBeVisible();
});

test("service worker serves the offline fallback without caching backend APIs", async ({
  page,
  context,
}) => {
  await page.goto("/login");
  await page.evaluate(async () => {
    await navigator.serviceWorker.ready;
  });
  await page.reload();
  await expect
    .poll(() =>
      page.evaluate(() => navigator.serviceWorker.controller !== null),
    )
    .toBe(true);
  await expect
    .poll(() =>
      page.evaluate(async () => (await fetch("/api/csrf")).status),
    { timeout: 10_000 },
    )
    .toBe(200);

  await context.setOffline(true);
  const offlineApiResult = await page.evaluate(async () => {
    try {
      return (await fetch("/api/csrf")).status;
    } catch {
      return null;
    }
  });
  expect(offlineApiResult).toBeNull();
  await page.goto("/");
  await expect(page.getByRole("heading", { name: "You’re offline" })).toBeVisible();
});

test("mobile navigation and keyboard shortcuts remain usable", async ({ page }) => {
  test.skip(
    externalApp || externalBackend,
    "This interaction test uses the local mock backend.",
  );

  await page.goto("/login");
  await page.getByLabel("Username").fill("playwright");
  await page.getByLabel("Password").fill("playwright-test-password");
  await page.getByRole("button", { name: "Log in" }).click();
  await expect(page).toHaveURL(/\/$/);
  await page.setViewportSize({ width: 360, height: 812 });

  const navigation = page.getByRole("navigation", { name: "Main navigation" });
  await expect(navigation).toBeVisible();
  await expect(navigation.locator("[data-view]:visible")).toHaveCount(5);
  const searchBounds = await page.locator(".search-wrap").evaluate((element) => {
    const input = element.querySelector("input")!.getBoundingClientRect();
    const shortcut = element.querySelector(".kbd")!.getBoundingClientRect();
    const bounds = element.getBoundingClientRect();
    return { inputRight: input.right, shortcutLeft: shortcut.left, shortcutRight: shortcut.right, right: bounds.right };
  });
  expect(searchBounds.inputRight).toBeLessThanOrEqual(searchBounds.shortcutLeft);
  expect(searchBounds.shortcutRight).toBeLessThanOrEqual(searchBounds.right);
  await expect(navigation.locator('[data-view="library"]')).toHaveAttribute(
    "aria-current",
    "page",
  );
  expect(
    await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth),
  ).toBe(true);

  await page.keyboard.press("?");
  await expect(page.getByRole("dialog", { name: "Keyboard shortcuts" })).toBeVisible();
  await expect(page.getByRole("dialog", { name: "Keyboard shortcuts" })).toHaveCount(1);
  await page.keyboard.press("Escape");
  await expect(page.getByRole("dialog", { name: "Keyboard shortcuts" })).toHaveCount(0);

  await navigation.getByRole("button", { name: "Favorites" }).click();
  await expect(navigation.locator('[data-view="favorites"]')).toHaveAttribute(
    "aria-current",
    "page",
  );

  await navigation.getByRole("button", { name: "Playlists" }).click();
  await page.getByRole("button", { name: "New playlist" }).first().click();
  const playlistName = `Mobile playlist ${Date.now()}`;
  const playlistNameInput = page.getByLabel("Playlist name");
  await expect(playlistNameInput).toBeFocused();
  await playlistNameInput.fill(playlistName);
  await page.getByRole("button", { name: "Create", exact: true }).click();
  await expect(page.locator(".view-title")).toContainText(playlistName);
  await expect(page.getByRole("heading", { name: "This playlist is empty" })).toBeVisible();
  await page.getByRole("button", { name: "All playlists" }).click();
  await expect(page.getByRole("button", { name: `Open playlist ${playlistName}` })).toBeVisible();
  await page.getByRole("textbox", { name: "Search playlists" }).fill("missing playlist");
  await expect(page.getByRole("heading", { name: "No playlists found" })).toBeVisible();
  await page.getByRole("button", { name: "Clear search" }).click();
  await page.getByRole("button", { name: `Open playlist ${playlistName}` }).click();
  const horizontalOverflow = await page.evaluate(() => ({
    viewportWidth: window.innerWidth,
    documentWidth: document.documentElement.scrollWidth,
    elements: [...document.querySelectorAll<HTMLElement>("body *")]
      .map((element) => ({
        tag: element.tagName,
        className: element.className,
        left: Math.round(element.getBoundingClientRect().left),
        right: Math.round(element.getBoundingClientRect().right),
        width: Math.round(element.getBoundingClientRect().width),
      }))
      .filter((element) => element.right > window.innerWidth + 1 || element.left < -1)
      .slice(0, 10),
  }));
  expect(horizontalOverflow.documentWidth, JSON.stringify(horizontalOverflow)).toBeLessThanOrEqual(
    horizontalOverflow.viewportWidth,
  );
});

test("liquid glass stays translucent and limits active surfaces", async ({ page }) => {
  test.skip(
    externalApp || externalBackend,
    "This interaction test uses the local mock backend.",
  );

  await page.goto("/login");
  await page.getByLabel("Username").fill("playwright");
  await page.getByLabel("Password").fill("playwright-test-password");
  await page.getByRole("button", { name: "Log in" }).click();
  await expect(page.getByRole("navigation", { name: "Main navigation" })).toBeVisible();
  await expect(page.locator(".rail.glass")).toBeVisible();
  await expect
    .poll(() =>
      page.locator(".rail.glass").evaluate((element) => getComputedStyle(element).backgroundColor),
    )
    .toBe("rgba(15, 18, 28, 0.3)");

  const glassState = await page.evaluate(() => {
    const rail = document.querySelector<HTMLElement>(".rail.glass");
    if (!rail) return null;
    const computed = getComputedStyle(rail);
    const filterUrl = rail.style.getPropertyValue("--glass-filter-url");
    const filterId = filterUrl.match(/#([^)]+)/)?.[1];
    const mapSource = filterId
      ? document.querySelector<SVGImageElement>(`#${CSS.escape(filterId)} feImage`)?.getAttribute("href")
      : null;
    return {
      background: computed.backgroundColor,
      backdropFilter: computed.backdropFilter,
      boxShadow: computed.boxShadow,
      glassCount: document.querySelectorAll(".glass").length,
      refract: rail.classList.contains("refract"),
      chromium: "chrome" in window,
      supportsRefraction: CSS.supports(
        "backdrop-filter",
        "blur(3px) url(#lg) saturate(170%)",
      ),
      mapSource,
    };
  });

  expect(glassState).not.toBeNull();
  expect(glassState?.background).toBe("rgba(15, 18, 28, 0.3)");
  expect(glassState?.backdropFilter).toMatch(/blur\((18|3)px\)/);
  expect(glassState?.boxShadow).toContain("inset");
  expect(glassState?.glassCount).toBeLessThanOrEqual(4);
  if (glassState?.chromium && glassState.supportsRefraction) {
    expect(glassState.refract).toBe(true);
    expect(glassState.mapSource).toMatch(/^data:image\/svg\+xml/);
  } else {
    expect(glassState?.refract).toBe(false);
  }

  await page.getByRole("button", { name: "Playlists" }).click();
  await page.getByRole("button", { name: "New playlist" }).first().click();
  await expect(page.getByRole("dialog", { name: "New playlist" })).toBeVisible();
  await expect(page.locator(".queue-picker-card.glass")).toBeVisible();
  await expect
    .poll(() => page.locator(".glass").count())
    .toBeLessThanOrEqual(4);
});

test("playback refreshes an expired signed Storage URL once", async ({ page }) => {
  test.skip(
    externalApp || externalBackend,
    "This deterministic playback test uses the local mock backend.",
  );
  await page.goto("/login");
  await page.getByLabel("Username").fill("playwright");
  await page.getByLabel("Password").fill("playwright-test-password");
  await page.getByRole("button", { name: "Log in" }).click();
  await expect(page).toHaveURL(/\/$/);

  await page.request.post("http://127.0.0.1:8100/__test/expire-next-media");
  const trackCard = await loadMockPlaybackTrack(page, "expired-url", 51);

  let expiredSignedUrlResponses = 0;
  let streamRedirects = 0;
  let signedStorageUrl: string | null = null;
  page.on("response", (response) => {
    if (
      response.url().includes("/storage/v1/object/sign/songs/") &&
      response.status() === 403
    ) {
      expiredSignedUrlResponses += 1;
    }
    if (/\/api\/tracks\/playwright-track-\d+\/stream$/.test(response.url())) {
      streamRedirects += 1;
      if (response.status() === 302) {
        signedStorageUrl = response.headers().location ?? null;
      }
    }
  });

  await trackCard.click();
  const audio = page.locator("audio");
  await expect
    .poll(() => audio.evaluate((element) => (element as HTMLAudioElement).currentTime))
    .toBeGreaterThan(0);
  await expect(page.locator("#nowbar")).toHaveAttribute("data-playback-status", "playing");
  if (!signedStorageUrl) {
    throw new Error("The stream endpoint did not return a signed Storage URL.");
  }
  const rangedResponse = await page.evaluate(async (url) => {
    const response = await fetch(url, {
      headers: { Range: "bytes=0-1" },
      cache: "no-store",
    });
    return {
      status: response.status,
      contentRange: response.headers.get("Content-Range"),
    };
  }, signedStorageUrl);
  expect(rangedResponse.status).toBe(206);
  expect(rangedResponse.contentRange).toMatch(/^bytes 0-1\//);
  expect(expiredSignedUrlResponses).toBeGreaterThan(0);
  expect(streamRedirects).toBe(2);
});

test("playback recovers from a transient media request failure without changing tracks", async ({
  page,
}) => {
  test.skip(
    externalApp || externalBackend,
    "This deterministic playback test uses the local mock backend.",
  );
  await page.goto("/login");
  await page.getByLabel("Username").fill("playwright");
  await page.getByLabel("Password").fill("playwright-test-password");
  await page.getByRole("button", { name: "Log in" }).click();
  await expect(page).toHaveURL(/\/$/);
  const trackCard = await loadMockPlaybackTrack(page, "transient-network", 52);
  await page.request.post("http://127.0.0.1:8100/__test/fail-media", {
    data: { count: 1 },
  });

  let streamRedirects = 0;
  page.on("response", (response) => {
    if (/\/api\/tracks\/playwright-track-\d+\/stream$/.test(response.url())) {
      streamRedirects += 1;
    }
  });

  const failedMediaResponse = page.waitForResponse(
    (response) =>
      response.url().includes("/storage/v1/object/sign/songs/") &&
      response.status() === 503,
  );
  await trackCard.click();
  expect((await failedMediaResponse).status()).toBe(503);
  const audio = page.locator("audio");
  await expect
    .poll(() => audio.evaluate((element) => (element as HTMLAudioElement).currentTime))
    .toBeGreaterThan(0);
  await expect(page.locator("#nowbar")).toHaveAttribute("data-playback-status", "playing");
  await expect(page.locator(".now-title")).toHaveText("transient-network");
  await expect
    .poll(() => audio.evaluate((element) => (element as HTMLAudioElement).currentTime))
    .toBeGreaterThan(1);
  const positionBeforeRetry = await audio.evaluate((element) => {
    const audioElement = element as HTMLAudioElement;
    const position = audioElement.currentTime;
    Object.defineProperty(audioElement, "error", {
      configurable: true,
      value: { code: MediaError.MEDIA_ERR_NETWORK, message: "Injected network interruption" },
    });
    audioElement.dispatchEvent(new Event("error"));
    Object.defineProperty(audioElement, "error", { configurable: true, value: null });
    return position;
  });
  await expect
    .poll(() => audio.evaluate((element) => (element as HTMLAudioElement).currentTime))
    .toBeGreaterThan(positionBeforeRetry);
  await expect(page.locator("#nowbar")).toHaveAttribute("data-playback-status", "playing");
  expect(streamRedirects).toBeLessThanOrEqual(2);
});

test("playback stops after bounded retries on a permanent media error", async ({ page }) => {
  test.skip(
    externalApp || externalBackend,
    "This deterministic playback test uses the local mock backend.",
  );
  await page.goto("/login");
  await page.getByLabel("Username").fill("playwright");
  await page.getByLabel("Password").fill("playwright-test-password");
  await page.getByRole("button", { name: "Log in" }).click();
  await expect(page).toHaveURL(/\/$/);
  const trackCard = await loadMockPlaybackTrack(page, "unsupported-audio", 53);

  let streamRedirects = 0;
  page.on("response", (response) => {
    if (/\/api\/tracks\/playwright-track-\d+\/stream$/.test(response.url())) {
      streamRedirects += 1;
    }
  });
  await trackCard.click();
  await expect
    .poll(() => page.locator("audio").evaluate((element) => (element as HTMLAudioElement).currentTime))
    .toBeGreaterThan(0);
  await page.locator("audio").evaluate((element) => {
    const audio = element as HTMLAudioElement;
    Object.defineProperty(audio, "error", {
      configurable: true,
      value: { code: MediaError.MEDIA_ERR_DECODE, message: "Injected decode failure" },
    });
    audio.dispatchEvent(new Event("error"));
    Object.defineProperty(audio, "error", { configurable: true, value: null });
    audio.pause();
  });
  await expect(page.locator("#nowbar")).toHaveAttribute("data-playback-status", "failed");
  await expect(page.locator(".toasts .toast").last()).toContainText("could not be played");
  expect(streamRedirects).toBe(1);
  await expect(page.locator(".tbtn-play")).toHaveAttribute("aria-busy", "false");
});

test("playback gives up after its bounded network retries", async ({ page }) => {
  test.skip(
    externalApp || externalBackend,
    "This deterministic playback test uses the local mock backend.",
  );
  await page.goto("/login");
  await page.getByLabel("Username").fill("playwright");
  await page.getByLabel("Password").fill("playwright-test-password");
  await page.getByRole("button", { name: "Log in" }).click();
  await expect(page).toHaveURL(/\/$/);
  const trackCard = await loadMockPlaybackTrack(page, "unavailable-network", 54);
  await page.request.post("http://127.0.0.1:8100/__test/fail-media", {
    data: { count: 10 },
  });

  let mediaRequests = 0;
  let streamRedirects = 0;
  page.on("response", (response) => {
    if (/\/api\/tracks\/playwright-track-\d+\/stream$/.test(response.url())) {
      streamRedirects += 1;
    }
  });
  page.on("response", (response) => {
    if (
      response.url().includes("/storage/v1/object/sign/songs/") &&
      response.status() === 503
    ) {
      mediaRequests += 1;
    }
  });
  await trackCard.click();
  await expect(page.locator("#nowbar")).toHaveAttribute("data-playback-status", "failed");
  await expect(page.locator(".toasts .toast").last()).toContainText("could not");
  expect(mediaRequests).toBeGreaterThan(0);
  expect(mediaRequests).toBeLessThanOrEqual(4);
  expect(streamRedirects).toBeLessThanOrEqual(2);
});

test("artist About section stops loading after profile lookup failures", async ({ page }) => {
  test.skip(
    externalApp || externalBackend,
    "This deterministic profile test uses the local mock backend.",
  );
  await page.goto("/login");
  await page.getByLabel("Username").fill("playwright");
  await page.getByLabel("Password").fill("playwright-test-password");
  await page.getByRole("button", { name: "Log in" }).click();
  await expect(page).toHaveURL(/\/$/);
  await loadMockPlaybackTrack(page, "artist-bio-unavailable", 55);
  await page.route("**/api/artists/profile?*", (route) =>
    route.fulfill({ status: 503, contentType: "application/json", body: "{}" }),
  );

  await page.getByRole("button", { name: "Artists" }).click();
  await page.locator(".artist-card-open").filter({ hasText: "Vervfy Test Artist" }).click();

  const about = page.locator(".artist-info");
  await expect(about).toHaveAttribute("aria-busy", "false", { timeout: 15_000 });
  await expect(about.locator(".artist-bio")).toHaveText(
    "No artist information is available yet.",
  );
  await expect(about.locator(".artist-bio")).not.toContainText("Looking up");
});

test("mock-backend login, upload, playback, seeking, playlist, and Range flow", async ({
  page,
}) => {
  test.skip(
    externalApp || externalBackend,
    "This deterministic full-flow test uses the local mock backend.",
  );
  test.setTimeout(180_000);
  const wav = makeWav();
  const hydrationErrors: string[] = [];
  page.on("console", (message) => {
    if (message.type() === "error" && /hydrated|hydration mismatch/i.test(message.text())) {
      hydrationErrors.push(message.text());
    }
  });

  await page.goto("/login");
  await page.getByLabel("Username").fill("playwright");
  await page.getByLabel("Password").fill("playwright-test-password");
  await page.getByRole("button", { name: "Log in" }).click();
  await expect(page).toHaveURL(/\/$/);
  await expect(page.getByRole("navigation", { name: "Main navigation" })).toBeVisible();
  await expect.poll(() => hydrationErrors).toEqual([]);
  await expect
    .poll(() => page.locator(".side-panel").evaluate((element) => getComputedStyle(element).position))
    .toBe("fixed");
  await expect
    .poll(() => page.locator(".rail").evaluate((element) => Math.round(element.getBoundingClientRect().height)))
    .toBeGreaterThanOrEqual(await page.evaluate(() => window.innerHeight - 2));
  await expect(page.locator(".home-profile-avatar img")).toBeVisible();
  await expect
    .poll(() => page.locator(".side-panel").evaluate((element) => element.hasAttribute("inert") && element.getAttribute("aria-hidden") === "true"))
    .toBe(true);

  await page.getByRole("button", { name: "Playlists" }).click();
  await expect(page.locator(".view-title")).toHaveText("Playlists");
  await page.getByRole("button", { name: "New playlist" }).first().click();
  await page.getByLabel("Playlist name").fill(`Playwright ${Date.now()}`);
  await page.getByRole("button", { name: "Create", exact: true }).click();
  await expect(page.locator(".view-title")).toContainText("Playwright");

  await page.getByRole("button", { name: "Library", exact: true }).click();
  const audioInputs = page.locator(".hidden-input[type='file']");
  await expect(audioInputs).toHaveCount(2);
  await expect(audioInputs.nth(0)).toHaveAttribute(
    "accept",
    "audio/*,.mp3,.m4a,.wav,.flac,.ogg,.oga,.aac,.opus,.weba",
  );
  await expect(audioInputs.nth(1)).toHaveAttribute(
    "accept",
    "audio/*,.mp3,.m4a,.wav,.flac,.ogg,.oga,.aac,.opus,.weba",
  );
  await page.locator(".hidden-input").first().setInputFiles(
    [
      ...Array.from({ length: 60 }, (_, index) => ({
        name: `pw-batch-${String(index + 1).padStart(2, "0")}.wav`,
        mimeType: "audio/wav",
        buffer: wav,
      })),
      { name: "not-a-song.mp4", mimeType: "video/mp4", buffer: Buffer.from("video") },
      { name: "notes.txt", mimeType: "text/plain", buffer: Buffer.from("notes") },
    ],
  );

  await expect(page.locator(".card")).toHaveCount(60, { timeout: 150_000 });
  await expect(page.locator(".toasts .toast").last()).toContainText("Saved 60 tracks", {
    timeout: 10_000,
  });
  const trackCard = page.locator(".card").filter({ hasText: "pw-batch-01" });
  await expect(trackCard).toBeVisible();
  await trackCard.getByRole("button", { name: "More options for pw-batch-01" }).click();
  const trackMenu = page.getByRole("menu", { name: "Options for pw-batch-01" });
  await expect(trackMenu.getByRole("menuitem", { name: "Play next" })).toBeVisible();
  await expect(trackMenu.getByRole("menuitem", { name: "Add to playlist" })).toBeVisible();
  await expect(trackMenu.getByRole("menuitem", { name: "Download for offline" })).toBeVisible();
  await expect(trackMenu.getByRole("menuitem", { name: "View artist: Vervfy Test Artist" })).toBeVisible();
  await trackMenu.getByRole("menuitem", { name: "Download for offline" }).click();
  await expect(page.locator(".toasts .toast").last()).toContainText(
    "Downloaded “pw-batch-01” for offline listening.",
  );
  await page.reload();
  await expect(trackCard).toBeVisible();
  await trackCard.getByRole("button", { name: "More options for pw-batch-01" }).click();
  const savedTrackMenu = page.getByRole("menu", { name: "Options for pw-batch-01" });
  await savedTrackMenu.getByRole("menuitem", { name: "Remove offline download" }).click();
  await expect(page.locator(".toasts .toast").last()).toContainText(
    "Removed “pw-batch-01” from offline storage.",
  );
  await trackCard.getByRole("button", { name: "More options for pw-batch-01" }).click();
  await expect(page.getByRole("menuitem", { name: "Download for offline" })).toBeVisible();
  const savedArtistMenuItem = page
    .getByRole("menu", { name: "Options for pw-batch-01" })
    .getByRole("menuitem", { name: "View artist: Vervfy Test Artist" });
  await expect(savedArtistMenuItem).toBeVisible();
  await savedArtistMenuItem.click();
  await expect(page.getByRole("heading", { name: "Vervfy Test Artist" })).toBeVisible();
  await page.getByRole("button", { name: "Library", exact: true }).click();
  await expect(trackCard).toBeVisible();
  await page.locator(".card").filter({ hasText: "pw-batch-60" }).click();
  const audio = page.locator("audio");
  await expect(page.locator(".now-title")).toHaveText("pw-batch-60");
  await expect
    .poll(() => audio.evaluate((element) => (element as HTMLAudioElement).currentTime))
    .toBeGreaterThan(0);
  await page.locator("audio").evaluate((element) => {
    element.dispatchEvent(new Event("ended"));
  });
  await expect(page.locator(".now-title")).toHaveText("pw-batch-01");
  await page.locator('.nowbar button[title="Queue"]').click();
  await expect(page.getByRole("complementary", { name: "Up next" })).toHaveClass(/open/);
  await expect
    .poll(() => page.locator(".side-panel").evaluate((element) => !element.hasAttribute("inert") && !element.hasAttribute("aria-hidden")))
    .toBe(true);
  await expect
    .poll(() => page.locator(".side-panel").evaluate((element) => {
      const rect = element.getBoundingClientRect();
      return Math.round(window.innerWidth - rect.right);
    }))
    .toBe(0);
  await page.getByRole("button", { name: "Close queue" }).click();

  await page.getByRole("button", { name: "Repeat: off" }).click();
  await expect(page.getByRole("button", { name: "Repeat: all" })).toBeVisible();
  await page.getByRole("button", { name: "Repeat: all" }).click();
  await expect(page.getByRole("button", { name: "Repeat: one" })).toBeVisible();
  await page.getByRole("button", { name: "Repeat: one" }).click();
  await expect(page.getByRole("button", { name: "Repeat: off" })).toBeVisible();

  await expect
    .poll(() => audio.evaluate((element) => (element as HTMLAudioElement).duration))
    .toBeGreaterThan(5);
  await expect
    .poll(() => audio.evaluate((element) => (element as HTMLAudioElement).currentTime))
    .toBeGreaterThan(0);
  const content = page.locator(".content");
  await content.evaluate((element) => element.scrollTo(0, 500));
  const scrollPosition = await content.evaluate((element) => element.scrollTop);
  expect(scrollPosition).toBeGreaterThan(0);
  await page.waitForTimeout(750);
  const expectedScrollPosition = await content.evaluate(
    (element, position) => Math.min(position, element.scrollHeight - element.clientHeight),
    scrollPosition,
  );
  await expect
    .poll(() => content.evaluate((element) => element.scrollTop))
    .toBe(expectedScrollPosition);
  await audio.evaluate((element) => (element as HTMLAudioElement).pause());
  await page.setViewportSize({ width: 360, height: 812 });
  const embeddedLyricsRange = page.waitForRequest((request) =>
    /\/api\/tracks\/playwright-track-\d+\/stream$/.test(request.url()) &&
    request.headers().range === "bytes=0-262143"
  );
  await page.locator('.nowbar button[aria-label="Lyrics"]').click();
  await embeddedLyricsRange;
  await expect(page.getByRole("dialog", { name: "Lyrics" })).toBeVisible();
  const lyricsControls = page.locator(".lyrics-player");
  for (const label of ["Previous track", "Play", "Next track", "Shuffle", "Repeat: off"]) {
    await expect(lyricsControls.getByRole("button", { name: label, exact: true })).toBeVisible();
  }
  expect(
    await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth),
  ).toBe(true);
  await audio.evaluate((element) => {
    const player = element as HTMLAudioElement;
    player.currentTime = 1;
    player.playbackRate = 0.25;
  });
  await lyricsControls.getByRole("button", { name: "Play", exact: true }).click();
  await expect.poll(() => audio.evaluate((element) => (element as HTMLAudioElement).paused)).toBe(false);
  const lyricsSeek = page.locator('.lyrics-overlay [aria-label="Track progress"]');
  await expect(lyricsSeek).toBeVisible();
  const lyricsSeekBounds = await lyricsSeek.boundingBox();
  expect(lyricsSeekBounds).not.toBeNull();
  const lyricsSeekY = (lyricsSeekBounds?.y ?? 0) + (lyricsSeekBounds?.height ?? 0) / 2;
  await page.mouse.move((lyricsSeekBounds?.x ?? 0) + (lyricsSeekBounds?.width ?? 0) * 0.2, lyricsSeekY);
  await page.mouse.down();
  await expect.poll(() => audio.evaluate((element) => (element as HTMLAudioElement).paused)).toBe(true);
  const lyricsPausedAt = await audio.evaluate((element) => (element as HTMLAudioElement).currentTime);
  await page.mouse.move((lyricsSeekBounds?.x ?? 0) + (lyricsSeekBounds?.width ?? 0) * 0.75, lyricsSeekY, { steps: 4 });
  await expect
    .poll(() => audio.evaluate((element) => (element as HTMLAudioElement).currentTime))
    .toBeCloseTo(lyricsPausedAt, 1);
  await page.mouse.up();
  await expect.poll(() => audio.evaluate((element) => (element as HTMLAudioElement).paused)).toBe(false);
  await expect
    .poll(() => audio.evaluate((element) => (element as HTMLAudioElement).currentTime))
    .toBeGreaterThan(3.5);
  await lyricsControls.getByRole("button", { name: "Pause", exact: true }).click();
  await expect.poll(() => audio.evaluate((element) => (element as HTMLAudioElement).paused)).toBe(true);
  await audio.evaluate((element) => { (element as HTMLAudioElement).playbackRate = 1; });
  await lyricsSeek.focus();
  await page.keyboard.press("End");
  await expect
    .poll(() => audio.evaluate((element) => (element as HTMLAudioElement).currentTime))
    .toBeGreaterThan(5.5);
  await audio.evaluate((element) => { (element as HTMLAudioElement).currentTime = 1; });
  await page.getByRole("button", { name: "Close lyrics" }).click();
  await page.setViewportSize({ width: 1280, height: 900 });

  await page.locator('.nowbar button[aria-label="Play"]').click();

  const seekBar = page.locator('.nowbar [aria-label="Track progress"]');
  const progressMotion = await page.locator(".nowbar .seek-fill, .nowbar .seek-thumb").evaluateAll(
    (elements) => elements.map((element) => {
      const style = getComputedStyle(element);
      return {
        property: style.transitionProperty.split(",")[0].trim(),
        duration: style.transitionDuration.split(",")[0].trim(),
      };
    }),
  );
  expect(progressMotion).toEqual([
    { property: "width", duration: "0.25s" },
    { property: "left", duration: "0.25s" },
  ]);
  const bounds = await seekBar.boundingBox();
  expect(bounds).not.toBeNull();
  const seekY = (bounds?.y ?? 0) + (bounds?.height ?? 0) / 2;
  await page.mouse.move((bounds?.x ?? 0) + (bounds?.width ?? 0) * 0.2, seekY);
  await page.mouse.down();
  await expect.poll(() => audio.evaluate((element) => (element as HTMLAudioElement).paused)).toBe(true);
  const pausedAt = await audio.evaluate((element) => (element as HTMLAudioElement).currentTime);
  await page.mouse.move((bounds?.x ?? 0) + (bounds?.width ?? 0) * 0.75, seekY, { steps: 4 });
  await expect
    .poll(() => audio.evaluate((element) => (element as HTMLAudioElement).currentTime))
    .toBeCloseTo(pausedAt, 1);
  await page.mouse.up();
  await expect.poll(() => audio.evaluate((element) => (element as HTMLAudioElement).paused)).toBe(false);
  await expect
    .poll(() => audio.evaluate((element) => (element as HTMLAudioElement).currentTime))
    .toBeGreaterThan(3.5);
  await audio.evaluate((element) => (element as HTMLAudioElement).pause());

  const streamUrl = await audio.evaluate((element) => (element as HTMLAudioElement).currentSrc);
  const rangeStatus = await page.evaluate(async (url) => {
    const response = await fetch(url, {
      headers: { Range: "bytes=0-1" },
      cache: "no-store",
    });
    return {
      status: response.status,
      contentRange: response.headers.get("Content-Range"),
    };
  }, streamUrl);
  expect(rangeStatus.status).toBe(206);
  expect(rangeStatus.contentRange).toMatch(/^bytes 0-1\//);
});

test("real-backend login, upload, playback, seek, playlist, and Range flow", async ({ page }) => {
  test.skip(
    !username || !password || !externalBackend,
    "Set PLAYWRIGHT_BACKEND_URL, PLAYWRIGHT_USERNAME, and PLAYWRIGHT_PASSWORD for a real backend.",
  );

  await page.goto("/login");
  await page.getByLabel("Username").fill(username!);
  await page.getByLabel("Password").fill(password!);
  await page.getByRole("button", { name: "Log in" }).click();
  await expect(page)
    .toHaveURL(/\/$/, { timeout: 15_000 })
    .catch(async () => {
      const message = await page.getByRole("alert").textContent().catch(() => null);
      throw new Error(
        message
          ? `FastAPI rejected the test login: ${message.trim()}`
          : `Login did not redirect to the app (current URL: ${page.url()}).`,
      );
    });
  await expect(page.getByRole("navigation", { name: "Main navigation" })).toBeVisible();

  await page.getByRole("button", { name: "Playlists", exact: true }).click();
  await page.getByRole("button", { name: "New playlist" }).first().click();
  await page.getByLabel("Playlist name").fill(`Playwright ${Date.now()}`);
  await page.getByRole("button", { name: "Create", exact: true }).click();
  await expect(page.locator(".view-title")).toContainText("Playwright");

  await page.getByRole("button", { name: "Library", exact: true }).click();
  await page.locator(".hidden-input").first().setInputFiles({
    name: "playwright-smoke.wav",
    mimeType: "audio/wav",
    buffer: makeWav(),
  });

  const trackCard = page.locator(".card").filter({ hasText: "playwright-smoke" });
  await expect(trackCard).toBeVisible({ timeout: 75_000 });
  await trackCard.click();

  const audio = page.locator("audio");
  await expect
    .poll(
      () =>
        audio.evaluate((element) => (element as HTMLAudioElement).duration),
      { timeout: 30_000 },
    )
    .toBeGreaterThan(5);
  await expect
    .poll(() => audio.evaluate((element) => (element as HTMLAudioElement).currentTime))
    .toBeGreaterThan(0);
  await page.locator('.nowbar button[title="Play/Pause"]').click();

  const seekBar = page.locator('.nowbar [aria-label="Track progress"]');
  const bounds = await seekBar.boundingBox();
  expect(bounds).not.toBeNull();
  await seekBar.click({
    position: { x: (bounds?.width ?? 0) * 0.75, y: (bounds?.height ?? 0) / 2 },
  });
  await expect
    .poll(() => audio.evaluate((element) => (element as HTMLAudioElement).currentTime))
    .toBeGreaterThan(3.5);

  const streamUrl = await audio.evaluate((element) => (element as HTMLAudioElement).currentSrc);
  const rangeStatus = await page.evaluate(async (url) => {
    const response = await fetch(url, {
      headers: { Range: "bytes=0-1" },
      cache: "no-store",
    });
    return {
      status: response.status,
      contentRange: response.headers.get("Content-Range"),
    };
  }, streamUrl);
  expect(rangeStatus.status).toBe(206);
});
