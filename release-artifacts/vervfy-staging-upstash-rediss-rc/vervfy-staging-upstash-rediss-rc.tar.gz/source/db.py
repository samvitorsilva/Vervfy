"""Database models and session setup for Vervfy.

DATABASE_URL is deliberately the only database configuration point.  Supabase
provides a normal PostgreSQL connection URL; SQLAlchemy also accepts a SQLite
URL in tests without changing application code.
"""
from __future__ import annotations

import os
import uuid
from datetime import datetime

from sqlalchemy import (
    Boolean,
    CheckConstraint,
    DateTime,
    Float,
    ForeignKey,
    ForeignKeyConstraint,
    Index,
    Integer,
    LargeBinary,
    String,
    Text,
    UniqueConstraint,
    Uuid,
    create_engine,
    event,
    func,
    make_url,
    text,
)
from sqlalchemy.orm import (
    DeclarativeBase,
    Mapped,
    Session,
    mapped_column,
    relationship,
    sessionmaker,
)

from staging_database_guard import validate_staging_database_url


def normalize_database_url(value: str) -> str:
    """Normalize PostgreSQL URLs to use the psycopg 3 driver."""
    value = value.strip()
    if value.startswith("postgres://"):
        return "postgresql+psycopg://" + value[len("postgres://"):]
    if value.startswith("postgresql://"):
        return "postgresql+psycopg://" + value[len("postgresql://"):]
    return value


def database_url() -> str:
    raw_value = os.environ.get("DATABASE_URL", "")
    if os.environ.get("VERVFY_ENVIRONMENT", "").strip().lower() == "staging":
        return validate_staging_database_url(raw_value, "app_runtime")

    value = raw_value.strip()
    if not value:
        raise RuntimeError("DATABASE_URL must be set (use your Supabase PostgreSQL connection string).")
    if (
        os.environ.get("VERVFY_ENVIRONMENT", "").strip().lower() == "local-test"
        or os.environ.get("VERVFY_STORAGE_BACKEND", "").strip().lower()
        == "filesystem"
    ):
        from storage_adapters import validate_local_configuration

        validate_local_configuration()
    value = normalize_database_url(value)
    if os.environ.get("VERVFY_ENVIRONMENT", "").strip().lower() == "production":
        parsed_url = make_url(value)
        if parsed_url.get_backend_name() == "postgresql" and parsed_url.query.get(
            "sslmode"
        ) not in {"require", "verify-ca", "verify-full"}:
            value = parsed_url.set(
                query={**parsed_url.query, "sslmode": "require"}
            ).render_as_string(hide_password=False)
    return value


DATABASE_URL = database_url()


def engine_connect_args(url: str) -> dict:
    return {"prepare_threshold": None} if url.startswith("postgresql+psycopg://") else {}


engine = create_engine(
    DATABASE_URL,
    pool_pre_ping=True,
    connect_args=engine_connect_args(DATABASE_URL),
)
SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)


def tenant_session(tenant_id: str) -> Session:
    """Create a session whose PostgreSQL transactions are scoped to one tenant."""
    if not tenant_id:
        raise ValueError("tenant_id must not be empty")
    return SessionLocal(info={"tenant_id": tenant_id})


@event.listens_for(SessionLocal, "after_begin")
def set_database_tenant(session: Session, transaction, connection) -> None:
    """Pass the session's explicit tenant into PostgreSQL RLS policies."""
    del transaction
    tenant_id = session.info.get("tenant_id")
    if isinstance(tenant_id, str) and tenant_id and connection.dialect.name == "postgresql":
        connection.execute(
            text("SELECT set_config('app.current_user_id', :tenant_id, true)"),
            {"tenant_id": tenant_id},
        )


class Base(DeclarativeBase):
    pass


class User(Base):
    __tablename__ = "users"
    id: Mapped[str] = mapped_column(String(32), primary_key=True)
    username: Mapped[str] = mapped_column(String(32), nullable=False, unique=True)
    username_key: Mapped[str] = mapped_column(String(32), nullable=False, unique=True, index=True)
    email: Mapped[str | None] = mapped_column(String(320), unique=True)
    email_verified: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=False, server_default=text("false")
    )
    pending_email: Mapped[str | None] = mapped_column(String(320))
    password_hash: Mapped[str | None] = mapped_column(String(128), nullable=True)
    created_at: Mapped[float] = mapped_column(Float, nullable=False)
    photo_data: Mapped[bytes | None] = mapped_column(LargeBinary, deferred=True)
    photo_mime: Mapped[str | None] = mapped_column(String(64))
    session_version: Mapped[int] = mapped_column(Integer, nullable=False, default=0, server_default="0")

    # Preserve the existing route code's sqlite.Row-style access.
    def __getitem__(self, key: str):
        return getattr(self, key)


class ProviderIdentity(Base):
    """Authentication identity; email is deliberately not an identity key."""

    __tablename__ = "provider_identities"
    issuer: Mapped[str] = mapped_column(String(255), primary_key=True)
    subject: Mapped[str] = mapped_column(String(255), primary_key=True)
    user_id: Mapped[str] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
    )
    created_at: Mapped[float] = mapped_column(Float, nullable=False)


class TrackRecord(Base):
    __tablename__ = "tracks"
    __table_args__ = (
        UniqueConstraint("user_id", "id", name="uq_tracks_user_id_id"),
        CheckConstraint(
            "cover_source IS NULL OR cover_source IN "
            "('embedded', 'upload', 'user', 'musicbrainz', 'audiodb', 'generated', 'placeholder', 'unknown')",
            name="ck_tracks_cover_source",
        ),
    )
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), primary_key=True)
    filename: Mapped[str] = mapped_column(String(512), nullable=False)
    title: Mapped[str] = mapped_column(String(512), nullable=False)
    artist: Mapped[str] = mapped_column(String(512), nullable=False)
    album: Mapped[str] = mapped_column(String(512), nullable=False)
    duration: Mapped[float] = mapped_column(Float, nullable=False, default=0)
    has_cover: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    cover_source: Mapped[str] = mapped_column(
        String(20), nullable=True, default="unknown", server_default="unknown"
    )
    cover_url: Mapped[str | None] = mapped_column(Text)
    custom_lyrics: Mapped[str | None] = mapped_column(Text)
    # Legacy rows keep their audio here; new uploads live in Supabase Storage and
    # only ``storage_path`` is stored.  ``deferred`` stops ordinary row loads
    # (``session.get``) from dragging the whole blob out of Postgres.
    audio_data: Mapped[bytes | None] = mapped_column(LargeBinary, nullable=True, deferred=True)
    storage_path: Mapped[str | None] = mapped_column(String(600), nullable=True)
    size_bytes: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    cover_data: Mapped[bytes | None] = mapped_column(LargeBinary, nullable=True, deferred=True)
    cover_path: Mapped[str | None] = mapped_column(String(600), nullable=True)
    media_version: Mapped[uuid.UUID] = mapped_column(Uuid, nullable=False, default=uuid.uuid4)
    cover_checked_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )


class ArtistPhoto(Base):
    __tablename__ = "artist_photos"
    __table_args__ = (
        CheckConstraint("source IN ('user', 'commons')", name="ck_artist_photos_source"),
    )
    user_id: Mapped[str] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), primary_key=True
    )
    normalized_artist_name: Mapped[str] = mapped_column(String(200), primary_key=True)
    jpeg_data: Mapped[bytes | None] = mapped_column(LargeBinary, nullable=True, deferred=True)
    storage_path: Mapped[str | None] = mapped_column(String(600))
    media_version: Mapped[uuid.UUID] = mapped_column(Uuid, nullable=False, default=uuid.uuid4)
    source: Mapped[str] = mapped_column(String(10), nullable=False)
    author: Mapped[str | None] = mapped_column(Text)
    license_name: Mapped[str | None] = mapped_column(String(100))
    license_url: Mapped[str | None] = mapped_column(Text)
    commons_page_url: Mapped[str | None] = mapped_column(Text)
    resized_for_display: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=False, server_default="false"
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now(), onupdate=func.now()
    )


class ArtistImage(Base):
    __tablename__ = "artist_images"
    __table_args__ = (
        CheckConstraint("status IN ('found', 'not_found')", name="ck_artist_images_status"),
    )

    normalized_artist_name: Mapped[str] = mapped_column(String(200), primary_key=True)
    audiodb_id: Mapped[str | None] = mapped_column(String(32))
    image_url: Mapped[str | None] = mapped_column(Text)
    banner_url: Mapped[str | None] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(10), nullable=False)
    fetched_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )


class TrackCoverCache(Base):
    __tablename__ = "track_cover_cache"
    __table_args__ = (
        CheckConstraint(
            "status IN ('found', 'not_found')",
            name="ck_track_cover_cache_status",
        ),
    )

    cache_key: Mapped[str] = mapped_column(String(64), primary_key=True)
    normalized_artist: Mapped[str] = mapped_column(String(512), nullable=False)
    normalized_title: Mapped[str] = mapped_column(String(512), nullable=False)
    audiodb_album_id: Mapped[str | None] = mapped_column(String(32))
    cover_url: Mapped[str | None] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(10), nullable=False)
    fetched_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )


class Favorite(Base):
    __tablename__ = "favorites"
    __table_args__ = (
        ForeignKeyConstraint(
            ["user_id", "track_id"],
            ["tracks.user_id", "tracks.id"],
            ondelete="CASCADE",
        ),
    )
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), primary_key=True)
    track_id: Mapped[str] = mapped_column(String(64), primary_key=True)


class Playlist(Base):
    __tablename__ = "playlists"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    position: Mapped[int] = mapped_column(Integer, nullable=False, default=0, server_default="0")
    last_played_at: Mapped[float | None] = mapped_column(Float, nullable=True)
    tracks: Mapped[list[PlaylistTrack]] = relationship(cascade="all, delete-orphan", order_by="PlaylistTrack.position")


class PlaylistTrack(Base):
    __tablename__ = "playlist_tracks"
    playlist_id: Mapped[str] = mapped_column(ForeignKey("playlists.id", ondelete="CASCADE"), primary_key=True)
    track_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    position: Mapped[int] = mapped_column(Integer, nullable=False)


class TrackListen(Base):
    __tablename__ = "track_listens"
    __table_args__ = (
        ForeignKeyConstraint(
            ["user_id", "track_id"],
            ["tracks.user_id", "tracks.id"],
            ondelete="CASCADE",
        ),
        Index("ix_track_listens_user_played", "user_id", "played_at"),
    )

    id: Mapped[str] = mapped_column(String(32), primary_key=True)
    user_id: Mapped[str] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), nullable=False
    )
    track_id: Mapped[str] = mapped_column(String(64), nullable=False)
    played_at: Mapped[float] = mapped_column(Float, nullable=False)


class UploadJob(Base):
    __tablename__ = "upload_jobs"
    id: Mapped[str] = mapped_column(String(32), primary_key=True)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    filename: Mapped[str] = mapped_column(String(512), nullable=False)
    storage_path: Mapped[str | None] = mapped_column(String(600), nullable=True, unique=True)
    processing_token: Mapped[uuid.UUID | None] = mapped_column(Uuid)
    track_id: Mapped[str | None] = mapped_column(String(64))
    cover_data: Mapped[bytes | None] = mapped_column(LargeBinary, nullable=True, deferred=True)
    attempts: Mapped[int] = mapped_column(Integer, nullable=False, default=0, server_default="0")
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="pending", index=True)
    error: Mapped[str | None] = mapped_column(String(500))
    created_at: Mapped[float] = mapped_column(Float, nullable=False)
