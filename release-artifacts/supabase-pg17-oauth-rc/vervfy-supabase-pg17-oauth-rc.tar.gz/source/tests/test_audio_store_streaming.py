from __future__ import annotations

import os
import tempfile
import unittest
from unittest.mock import patch

import httpx

import audio_store


class AudioStoreStreamingTests(unittest.TestCase):
    def test_bucket_privacy_requires_explicit_private_metadata(self) -> None:
        for payload, expected in (
            ({"public": False}, True),
            ({"public": True}, False),
            ({}, None),
        ):
            with self.subTest(payload=payload):
                client = httpx.Client(
                    transport=httpx.MockTransport(
                        lambda request, value=payload: httpx.Response(
                            200, json=value
                        )
                    ),
                    base_url="https://storage.example.test",
                )
                with client, patch.object(audio_store, "_client", return_value=client), patch.dict(
                    os.environ,
                    {
                        "SUPABASE_URL": "https://project.supabase.co",
                        "SUPABASE_SERVICE_KEY": "test-key",
                    },
                ):
                    if expected is None:
                        with self.assertRaises(audio_store.StorageError):
                            audio_store.bucket_is_private()
                    else:
                        self.assertEqual(audio_store.bucket_is_private(), expected)

    def test_bucket_privacy_fails_closed_on_provider_error(self) -> None:
        client = httpx.Client(
            transport=httpx.MockTransport(
                lambda request: httpx.Response(403, text="denied")
            ),
            base_url="https://storage.example.test",
        )
        with client, patch.object(audio_store, "_client", return_value=client), patch.dict(
            os.environ,
            {
                "SUPABASE_URL": "https://project.supabase.co",
                "SUPABASE_SERVICE_KEY": "test-key",
            },
        ), self.assertRaises(audio_store.StorageError):
            audio_store.bucket_is_private()

    def test_unmanaged_upload_is_rejected_before_network(self) -> None:
        with patch.object(audio_store,"_client") as client, self.assertRaises(audio_store.StorageError):
            audio_store.upload("legacy/path",b"private")
        client.assert_not_called()

    def test_signed_url_cache_reuses_until_one_minute_before_expiry(self) -> None:
        requests = 0
        clock = [100.0]

        def handler(request: httpx.Request) -> httpx.Response:
            nonlocal requests
            requests += 1
            return httpx.Response(
                200,
                json={"signedURL": f"/object/sign/songs/user/track?token={requests}"},
            )

        audio_store.close_client()
        with (
            patch.object(audio_store, "_transport", httpx.MockTransport(handler)),
            patch.object(audio_store.time, "monotonic", side_effect=lambda: clock[0]),
            patch.dict(
                os.environ,
                {
                    "SUPABASE_URL": "https://project.supabase.co",
                    "SUPABASE_SERVICE_KEY": "test-key",
                },
            ),
        ):
            with audio_store._signed_url_cache_lock:
                audio_store._signed_url_cache.clear()
            try:
                first = audio_store.create_signed_url(
                    "user/track.mp3", expires_in=60 * 60
                )
                reused = audio_store.create_signed_url(
                    "user/track.mp3", expires_in=60 * 60
                )
                clock[0] += 60 * 60 - 60 + 1
                expired = audio_store.create_signed_url(
                    "user/track.mp3", expires_in=60 * 60
                )
            finally:
                audio_store.close_client()
                with audio_store._signed_url_cache_lock:
                    audio_store._signed_url_cache.clear()

        self.assertEqual(first, reused)
        self.assertNotEqual(first, expired)
        self.assertEqual(requests, 2)

    def test_unmanaged_file_upload_is_rejected_before_network(self) -> None:
        with patch.object(audio_store,"_client") as client, self.assertRaises(audio_store.StorageError):
            audio_store.upload_file("legacy/path","unused-file")
        client.assert_not_called()


if __name__ == "__main__":
    unittest.main()
